package com.mayuri.lastfm.di.module;

import android.content.Context;

import com.mayuri.lastfm.di.qualifier.ApplicationContext;
import com.mayuri.lastfm.di.scope.ApplicationScope;
import dagger.Module;
import dagger.Provides;



@Module
public class ContextModule {
    private Context context;

    public ContextModule(Context context) {
        this.context = context;
    }

    @Provides
    @ApplicationScope
    @ApplicationContext
    public Context provideContext() {
        return context;
    }
}
