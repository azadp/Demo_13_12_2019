package com.mayuri.lastfm.ui;

import com.mayuri.lastfm.pojo.Album;

import java.util.ArrayList;

public class MainActivityPresenter implements MainActivityContract.Presenter {
    private MainActivityContract.View view;
    ArrayList<Album> listOfMessages;

    public MainActivityPresenter(MainActivityContract.View view, ArrayList<Album> listOfMessages) {
        this.view = view;
        this.listOfMessages = listOfMessages;

    }


    @Override
    public void searchText(String message) {
        if (message != null && !message.isEmpty()) {
            view.notifyDataSearch(listOfMessages);
            view.clearMessageInput();
        }
    }

    @Override
    public void messageInputTextChanged(String messageInput) {
        if (messageInput == null || messageInput.isEmpty()) {
            view.disableSendButton();
        } else {
            view.enableSendButton();
        }
    }
}
